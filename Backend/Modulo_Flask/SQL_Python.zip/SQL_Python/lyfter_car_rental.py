# app.py
from flask import Flask, request, jsonify
from db_manager import UserRepository
from db_connection import ConnectionManager

app = Flask(__name__)

db_manager = ConnectionManager()
repo = UserRepository(db_manager)

@app.route("/users", methods=["POST"])
def create_user():
    data = request.json
    user_id = repo.add_user(
        data.get("first_name"), data.get("email"),
        data.get("username"), data.get("password"),
        data.get("birthdate")
    )
    if user_id:
        return jsonify({"message": "User created", "id": user_id}), 201
    return jsonify({"error": "Could not create user"}), 400

@app.route("/cars", methods=["POST"])
def create_car():
    data = request.json
    # Usando 'brand' y 'model'
    car_id = repo.add_car(data.get("brand"), data.get("model"), data.get("year"))
    if car_id:
        return jsonify({"message": "Car created", "id": car_id}), 201
    return jsonify({"error": "Could not create car"}), 400

@app.route("/rentals", methods=["POST"])
def create_rental():
    data = request.json
    rental_id = repo.create_rental(data.get("user_id"), data.get("car_id"))
    if rental_id:
        return jsonify({"message": "Rental created successfully", "id": rental_id}), 201
    return jsonify({"error": "Could not create rental (car unavailable)"}), 400

@app.route("/cars/<int:car_id>/state", methods=["PUT"])
def change_car_state(car_id):
    new_state = request.json.get("state")
    if repo.update_car_state(car_id, new_state):
        return jsonify({"message": f"Car state updated to {new_state}"})
    return jsonify({"error": "Error updating car state"}), 400

@app.route("/users/<int:user_id>/state", methods=["PUT"])
def change_user_state(user_id):
    new_state = request.json.get("state")
    if repo.update_user_state(user_id, new_state):
        return jsonify({"message": f"User state updated to {new_state}"})
    return jsonify({"error": "Error updating user state"}), 400

@app.route("/users/<int:user_id>/flag", methods=["PUT"])
def flag_user_moroso(user_id):
    # Flag user as defaulted
    if repo.update_user_state(user_id, "defaulted"):
        return jsonify({"message": "User flagged as defaulted"})
    return jsonify({"error": "Error flagging user"}), 400

@app.route("/rentals/<int:rental_id>/state", methods=["PUT"])
def change_rental_state(rental_id):
    new_state = request.json.get("state")
    if repo.update_rental_state(rental_id, new_state):
        return jsonify({"message": f"Rental state updated to {new_state}"})
    return jsonify({"error": "Error updating rental state"}), 400

@app.route("/rentals/<int:rental_id>/complete", methods=["PUT"])
def complete_rental(rental_id):
    if repo.complete_rental(rental_id):
        return jsonify({"message": "Rental completed and car marked as available"})
    return jsonify({"error": "Error completing rental or already completed"}), 400

@app.route("/users", methods=["GET"])
def list_users():
    filters = request.args.to_dict()
    users = repo.get_filtered_data("users", filters)
    return jsonify(users)

@app.route("/cars", methods=["GET"])
def list_cars():
    filters = request.args.to_dict()
    cars = repo.get_filtered_data("cars", filters)
    return jsonify(cars)

@app.route("/rentals", methods=["GET"])
def list_rentals():
    filters = request.args.to_dict()
    rentals = repo.get_filtered_data("car_rental", filters)
    return jsonify(rentals)

if __name__ == "__main__":
    app.run(debug=True, port=5000)